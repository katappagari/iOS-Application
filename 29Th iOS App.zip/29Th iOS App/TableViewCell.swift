//
//  TableViewCell.swift
//  29Th frb
//
//  Created by Ranjith Kumar on 29/02/24.
//

import UIKit

class TableViewCell: UITableViewCell {


    @IBOutlet weak var lastNameLabel: UILabel!
   
    @IBOutlet weak var firstnameLabel: UILabel!
    
    @IBOutlet weak var idLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    
    @IBOutlet weak var imageIcon: UIImageView!
    func configure(with user: User) {
           idLabel.text = "\(user.id)"
           emailLabel.text = user.email
           firstnameLabel.text = user.first_name
           lastNameLabel.text = user.last_name

           // Assuming avatar is a URL, you might want to load it asynchronously
           if let imageURL = URL(string: user.avatar) {
               DispatchQueue.global().async {
                   if let data = try? Data(contentsOf: imageURL),
                      let image = UIImage(data: data) {
                       DispatchQueue.main.async {
                           self.imageIcon.image = image
                       }
                   }
               }
           }
       }
   
    
}
