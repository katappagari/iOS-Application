//
//  DataParse.swift
//  29Th frb
//
//  Created by Ranjith Kumar on 29/02/24.
//

import Foundation

//struct User: Codable {
//    let id: Int
//    let email: String
//    let firstName: String
//    let lastName: String
//    let avatar: String
//}
//
//struct UserData: Codable {
//    let page: Int
//    let perPage: Int
//    let total: Int
//    let totalPages: Int
//    let data: [User]
//
//}

