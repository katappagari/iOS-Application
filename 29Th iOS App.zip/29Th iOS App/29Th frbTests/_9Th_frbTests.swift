//
//  _9Th_frbTests.swift
//  29Th frbTests
//
//  Created by Ranjith Kumar on 29/02/24.
//

import XCTest
@testable import _9Th_frb


final class _9Th_frbTests: XCTestCase {
    
    
    var viewController: ViewController!

    override func setUpWithError() throws {
        viewController = UIStoryboard(name: "Main", bundle: nil)
            .instantiateViewController(withIdentifier: "ViewController") as? ViewController
        _ = viewController.view
    }

    override func tearDownWithError() throws {
        viewController = nil
    }
    
    override func setUp() {
           super.setUp()
         
       }

    func testViewDidLoad() {
           XCTAssertNotNil(viewController)
           
           XCTAssertTrue(viewController.notifyLabel.isHidden)
           XCTAssertEqual(viewController.pageNumber, 1)
           XCTAssertEqual(viewController.swipeCount, 0)
       }
    


func testLeftSwipeonTB() {
    let tableView = viewController.tb
    let initialPageNumber = viewController.pageNumber
    let expectedUpdatedPageNumber = initialPageNumber + 1

    let swipeGesture = UISwipeGestureRecognizer()
    swipeGesture.direction = .left
    viewController.handleSwipe(swipeGesture)

    XCTAssertEqual(viewController.pageNumber, expectedUpdatedPageNumber)
}
    
    
func testRightSwipeonTB() {
         let tableView = viewController.tb
         let initialPageNumber = viewController.pageNumber
         let expectedUpdatedPageNumber = max(initialPageNumber - 1, 1)

         let swipeGesture = UISwipeGestureRecognizer()
         swipeGesture.direction = .right
         viewController.handleSwipe(swipeGesture)

         XCTAssertEqual(viewController.pageNumber, expectedUpdatedPageNumber)
     }
    
    override func tearDown() {
        super.tearDown()
    }
    
}
