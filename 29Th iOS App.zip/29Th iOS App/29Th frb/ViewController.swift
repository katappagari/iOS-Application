//
//  ViewController.swift
//  29Th frb
//
//  Created by Ranjith Kumar on 29/02/24.
//

import UIKit


class ViewController: UIViewController {


    @IBOutlet weak var stackData: UIStackView!
    @IBOutlet weak var notifyLabel: UILabel!
    @IBOutlet weak var btnOne: UILabel!
    @IBOutlet weak var btnTwo: UILabel!
    @IBOutlet weak var btnThree: UILabel!
    @IBOutlet weak var btnFour: UILabel!
    
    @IBOutlet weak var tb: UITableView!
    var userData: dataModel?
    var pageNumber = 1
    var swipeCount = 0
    

    var finalData: dataModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.notifyLabel.isHidden = true

        let nib = UINib(nibName: "TableViewCell", bundle: nil)
           tb.register(nib, forCellReuseIdentifier: "TableViewCell")
        tb.dataSource = self
        tb.delegate = self
        // Do any additional setup after loading the view.
        
        fetchData { result in
            self.tb.startAnimatingShimmerEffect()
            self.stackData.startAnimatingShimmerEffect()
            switch result {
            case .success(let userModel):
                DispatchQueue.main.async {
                    self.updateUI(with: userModel)
                    self.userData = userModel
    //                    self.updateUI(with: userModel)
    //                    self.userData = userModel
                        if userModel.data.count <= 0 {
                            self.swipeCount = 1
                            self.notifyLabel.isHidden = false
                            self.notifyLabel.text = "Sorry!, We Do not have any data in Future Pages"
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1){
                                self.notifyLabel.isHidden = true
                                self.tb.stopAnimatingShimmerEffect()
                                self.stackData.stopAnimatingShimmerEffect()
                            }
                        } else {
                            self.updateUI(with: userModel)
                            self.userData = userModel
                            self.tb.reloadData()
                            
                        }
                        
                       
                    }
            
            case .failure(let error):
                print("API error: \(error)")
            }
        }
        
        
        let swipeRightGestureLrft = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe))
        swipeRightGestureLrft.direction = .left
         tb.addGestureRecognizer(swipeRightGestureLrft)
        
        let swipeRightGestureRight = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe))
        swipeRightGestureRight.direction = .right
         tb.addGestureRecognizer(swipeRightGestureRight)

    }



    
    func fetchData(completion: @escaping (Result<dataModel, Error>) -> Void) {
        tb.startAnimatingShimmerEffect()
        stackData.startAnimatingShimmerEffect()
        
        let apiString = "https://reqres.in/api/users?page=\(pageNumber)"
        
        if let serviceUrl = URL(string: apiString) {
            URLSession.shared.dataTask(with: serviceUrl) { (data, _, error) in
                if let error = error {
                    DispatchQueue.main.async {
                        completion(.failure(error))
                    }
                } else if let data = data {
                    do {
                        let userModel = try JSONDecoder().decode(dataModel.self, from: data)
                        DispatchQueue.main.async {
                            completion(.success(userModel))
                        }
                    } catch {
                        DispatchQueue.main.async {
                            completion(.failure(error))
                        }
                    }
                }
            }.resume()
        }
    }

    
    
    func updateUI(with userModel: dataModel) {
       print(userModel.page)
        btnOne.text = String(userModel.page)
                    
            btnOne.text = "Page: \(String(userModel.page))"

        btnTwo.text =  "Number Of Items Listed: \(String(userModel.per_page))"

        btnThree.text =  "Total Number of Lists: \(String(userModel.total))"

        btnFour.text =  "Total Pages: \(String(userModel.total_pages))"

  

    }
    
    
    @objc func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
        if gesture.direction == .left {
             if swipeCount == 0 {
            pageNumber += 1
              }
            
        } else if gesture.direction == .right {
           swipeCount = 0
            if pageNumber >= 3 {
                pageNumber = 2
            }
            pageNumber = max(pageNumber - 1, 1)
        }
            
            fetchData { result in
                switch result {
                case .success(let userModel):
                    DispatchQueue.main.async {
                        
                   self.userData = userModel
                        if userModel.data.count <= 0 {
                            self.swipeCount = 1
                            //self.pageNumber = 2
                            self.notifyLabel.isHidden = false
                            self.notifyLabel.text = "Sorry!, We Do not have any data in Future Pages"
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.7){
                                self.notifyLabel.isHidden = true
                                self.tb.stopAnimatingShimmerEffect()
                                self.stackData.stopAnimatingShimmerEffect()
                            }
                        } else {
                            self.updateUI(with: userModel)
                            self.userData = userModel
                            self.tb.reloadData()
                            
                        }
                        
                        
                    }
                    
                case .failure(let error):
                    print("API error: \(error)")
                }
            }
        
    }
    

    

      
    
}
            



extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if let data = userData?.data.count{
            if data <= 0 {
                

            }
        }
        return userData?.data.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as? TableViewCell,
                     let user = userData?.data[indexPath.row] else {
                   return UITableViewCell()
               }

               cell.configure(with: user)
        self.tb.stopAnimatingShimmerEffect()
        self.stackData.stopAnimatingShimmerEffect()
               return cell
           }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
}

struct dataModel: Codable {
    let page: Int
    let per_page: Int
    let total: Int
    let total_pages: Int
    let data: [User]
    
}

struct User: Codable {
    let id: Int
    let email: String
    let first_name: String
    let last_name: String
    let avatar: String
}

//SHIMMER ANIMATUON

extension UIView {
    
    
    
    func addAnimation() -> CABasicAnimation {
        let animation = CABasicAnimation(keyPath: "locations")
        animation.fromValue = [-1.0, -0.5, 0.0]
        animation.toValue = [1.0, 1.5, 2.0]
        animation.repeatCount = .infinity
        animation.duration = 0.9
        return animation
    }
        
        func startAnimatingShimmerEffect(isFaded:Bool = false, isBlue:Bool = false) {
                let gradientLayer = addGradientLayer(isFaded: isFaded,isBlue: isBlue)
                let animation = addAnimation()
                gradientLayer.add(animation, forKey: animation.keyPath)
            
        }

        
        func stopAnimatingShimmerEffect() {
            if let shimmerLayer = (self.layer.sublayers?.compactMap { $0 as? CAGradientLayer })?.first {
                shimmerLayer.removeFromSuperlayer()
            }
        }
        
    func addGradientLayerWithCustomColors(color1:CGColor, color2:CGColor) -> CAGradientLayer {
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = self.bounds
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 1.0)
        gradientLayer.colors = [color1, color2, color1]
        
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.cornerRadius = 5
        self.layer.addSublayer(gradientLayer)
        
        return gradientLayer
    }
    
    func addGradientLayer(isFaded:Bool, isBlue:Bool) -> CAGradientLayer {
        
        let gradientLayer = CAGradientLayer()
        
        gradientLayer.frame = self.bounds
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 1.0)
        if isBlue{
            if isFaded {
                gradientLayer.colors = [gradientLightBlueClorOne, gradientLightBlueClorTwo, gradientLightBlueClorOne]
            } else {
                gradientLayer.colors = [gradientBlueClorOne, gradientBlueClorTwo, gradientBlueClorOne]
            }
        }else{
            if isFaded {
                gradientLayer.colors = [gradientLightColorOne, gradientLightColorTwo, gradientLightColorOne]
            } else {
                gradientLayer.colors = [gradientColorOne, gradientColorTwo, gradientColorOne]
            }
        }
        
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.cornerRadius = 5
        self.layer.addSublayer(gradientLayer)
        
        return gradientLayer
    }


}
var gradientSave: CAGradientLayer?
var gradientAdd: CAGradientLayer?
var gradientColorOne : CGColor = #colorLiteral(red: 0.8509803922, green: 0.8509803922, blue: 0.8509803922, alpha: 1).cgColor
var gradientColorTwo : CGColor = #colorLiteral(red: 0.9490196078, green: 0.9490196078, blue: 0.9490196078, alpha: 1).cgColor
var gradientLightColorOne : CGColor = UIColor(white: 0.85, alpha: 0.6).cgColor
var gradientLightColorTwo : CGColor = UIColor(white: 0.95, alpha: 0.6).cgColor
var gradientBlueClorOne : CGColor = #colorLiteral(red: 0.1559853256, green: 0.1811880767, blue: 0.5953054428, alpha: 1).cgColor
var gradientBlueClorTwo : CGColor = #colorLiteral(red: 0.4104347229, green: 0.5243577361, blue: 0.8007316589, alpha: 1).cgColor
var gradientLightBlueClorOne : CGColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.1800962537).cgColor
var gradientLightBlueClorTwo : CGColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.6015313761).cgColor
